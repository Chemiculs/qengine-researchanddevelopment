#include "enc_t.hpp"

namespace crypto {
	bool crypto::is_init = false;
	unsigned long long crypto::seed = 0x0000000000000000ULL;
}