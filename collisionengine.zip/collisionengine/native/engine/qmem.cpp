#include "qmem.hpp"

namespace qmem {

	std::mutex qmem::callback_mutex{};

}