#ifndef QBASE_H
#define QBASE_H

#pragma once

#include "qcallback.hpp"
#include "../qutil/qutil.hpp"

#endif