// collisionengine.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <vector>
#include <thread>
#include <random>

#include "native/qhash/qhash.hpp"
#include "native/qutil/qutil.hpp"


/*
8-bit unsigned integer (unsigned char): Maximum value is 255
16-bit unsigned integer (unsigned short): Maximum value is 65,535
32-bit unsigned integer (unsigned int): Maximum value is 4,294,967,295
64-bit unsigned integer (unsigned long long): Maximum value is 18,446,744,073,709,551,615
*/

#pragma region Type Constants

#define UCHAR_MAX 255ui8

#define USHORT_MAX 65535ui16

#define UINT_MAX 4294967295ui32

#define UINT64_MAX 18446744073709551615ui64

#pragma endregion


#pragma region Globals

static void* data_ptr;
static size_t data_size;
static std::thread data_thread;
    
bool thread_state_flag = true;
#pragma endregion

__forceinline void __fastcall randomize_data_set(void* data_start, size_t data_length) {

}

void data_collision_thread() {
    bool hasreset = false; // if / when generated data sets exceeds 18446744073709551615 we need to know so dataset size does not drop down to lower size 

    size_t iterations = 0x1;

    while (thread_state_flag) {
        for (auto i = 0; i < data_size; ++i){
            reinterpret_cast<byte*>(data_ptr)[i] = 0x0ui8; // reset data
        }

        for (auto i = 0; i < data_size; ++i) {
            for (auto x = 0; x < (UCHAR_MAX + 1); ++x) {
                if (i) {

                    auto preiter_passes = (i > 1 ? (i - 1) : 1);

                    for (auto y = 0; y < i; ++y) {

                        break;
                    }
                }
                else {
                    reinterpret_cast<byte*>(data_ptr)[x] = static_cast<byte>(x);
                }
            }
        }

        data_size = iterations;
        ++iterations;
    }
}

typedef struct collision_t {
    int index_x;
    int index_y;

    collision_t(int xx, int yy) {
        index_x = xx;
        index_y = yy;
    }
};
int  __cdecl main()
{
    byte b = 0x0;
    ushort us = 0x0;
    uint ui = 0x0;
    uint64 ui64 = 0x0;


    std::vector<uint32> vec{};
    std::cout << "generating all potential hashed 16-bit values..." << std::endl;
    for (auto i = 0; i <= USHORT_MAX; ++i) {
        auto hash = qhash::qhash32(&us, sizeof(us));

        //std::wcout << qutil::get_hex_wstring(&hash.hash, sizeof(hash.hash)) << std::endl;

        vec.push_back(hash.hash);

        ++us;
    }

    size_t collision_counter = 0x0;
    std::vector<collision_t> cvec{};
    std::cout << "checking for collisions in all 16-bit hash values... " << std::endl;
    for (auto i = 0; i <= USHORT_MAX; ++i) {
        for (auto x = 0; x <= USHORT_MAX; ++x) {
            if (x == i) {
                continue;
            }
            if (vec[i] == vec[x]) {
                bool contained = false;
                for (auto y = 0; y < cvec.size(); ++y) {
                    if ((cvec[y].index_x == i && cvec[y].index_y == x) || (cvec[y].index_x == x && cvec[y].index_y == i)) {
                        contained = true;
                        continue;
                    }
                }
                if (!contained) {
                    //std::cout << "collision detected, count: " << collision_counter + 1 << std::endl;
                    cvec.push_back(collision_t(i, x));
                    ++collision_counter;
                }
            }
        }
    }
    std::wcout << L"done, collisions detected: " << collision_counter << std::endl;

    getchar();
}